/*****Auto generated header file, Please DO NOT modify manually!*****/
#ifndef _VSI_NN_FEATURE_CONFIG_H
#define _VSI_NN_FEATURE_CONFIG_H

#define VSI_PERCHANNEL_QUANTIZATION_SUPPORT

#endif
